//
//  Student.swift
//  MidTerm_MADF2017
//
//  Created by moxDroid on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Student ID : C0713440
//  Student Name : Swetha

import Foundation

class Student {
    var studentId:Int?;
    var studentName:String?;
    var email:String?;
    var birthDate:Date!;
    static var studentList = [Int:Student]();
    
    init(){
        studentId = 1;
        studentName = "Swetha";
        email = "swetha.sk7@gmail.com";
        birthDate = Date();
    }
    
    init(_ studentId:Int,_ studentName:String,_ email:String, _ birthDate:Date){
        self.studentId = studentId;
        self.studentName = studentName;
        self.email = email;
        self.birthDate = birthDate;
    }
    
    static func addStudent(student: Student){
        self.studentList[student.studentId!] = student;
    }
    
    static func getAllStudent()-> [Int:Student]{
        return self.studentList;
    }
 
    
    
}
