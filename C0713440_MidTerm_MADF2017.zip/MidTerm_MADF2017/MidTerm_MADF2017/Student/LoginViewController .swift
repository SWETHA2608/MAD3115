//
//  ViewController.swift
//  MidTerm_MADF2017
//
//  Created by moxDroid on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Student ID : C0713440
//  Student Name : Swetha

import UIKit

class LoginViewController : UIViewController {
    
    @IBOutlet weak var txtUserName: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    var userID = UserDefaults.standard;
    //var alert:UIAlertController;
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func onClickLogin(_ sender: UIButton) {
        
        if( txtUserName.text == "C0713440" && txtPassword.text == "Swetha"){
            let storyBoard: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let studentEntryViewController = storyBoard.instantiateViewController(withIdentifier: "studentEntryScreen") as! StudentEntryViewController
            self.present(studentEntryViewController, animated: true, completion: nil);
            userID.set(txtUserName.text, forKey: "UserID")
        }else{
            let alert = UIAlertController(title: "Message", message: "Incorrect User", preferredStyle: UIAlertControllerStyle.alert);
            //Cancel Action
            let cancelAction =  UIAlertAction(title: "Cancel", style: UIAlertActionStyle.cancel, handler: {
                _ in print("Incorrect Username!!!! Try again");
            })
            alert.addAction(cancelAction);
            self.present(alert, animated: true, completion: nil);
        }
    }
}

