//
//  StudentEntryViewController.swift
//  MidTerm_MADF2017
//
//  Created by moxDroid on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Student ID : C0713440
//  Student Name : Swetha

import UIKit

class StudentEntryViewController: UIViewController {

    var userID = UserDefaults.standard;
    @IBOutlet weak var lblUserID: UILabel!
    @IBOutlet weak var txtStudentID: UITextField!
    @IBOutlet weak var txtStudentName: UITextField!
    @IBOutlet weak var txtStudentEmail: UITextField!
    @IBOutlet weak var txtBirthDate: UITextField!
    @IBOutlet weak var txtMark1: UITextField!
    @IBOutlet weak var txtMark2: UITextField!
    @IBOutlet weak var txtMark3: UITextField!
    @IBOutlet weak var txtMark4: UITextField!
    @IBOutlet weak var txtMark5: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

    @IBAction func onClickCalculateResults(_ sender: UIButton) {
 
        let student = Student();
        
        student.studentId = Int(txtStudentID.text!);
        student.studentName = String(describing: txtStudentName.text);
        student.email = String(describing: txtStudentEmail.text);

        let dateFormatter = DateFormatter();
        dateFormatter.dateFormat = "dd-mm-yyyy";
        student.birthDate = dateFormatter.date(from: txtBirthDate.text!)
        
        Student.addStudent(student: student);
        
        let studentResultViewController = self.storyboard?.instantiateViewController(withIdentifier: "studentResultScreen") as! StudentResultViewController
        self.present(studentResultViewController, animated: true, completion: nil);
    }
}
