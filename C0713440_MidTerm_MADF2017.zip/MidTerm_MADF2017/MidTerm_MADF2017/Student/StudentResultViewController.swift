//
//  StudentResultViewController.swift
//  MidTerm_MADF2017
//
//  Created by moxDroid on 2017-10-20.
//  Copyright © 2017 moxDroid. All rights reserved.
//  Student ID : C0713440
//  Student Name : Swetha

import UIKit

class StudentResultViewController: UIViewController {

    var userID = UserDefaults.standard;
    @IBOutlet weak var lblUserID: UILabel!
    
    @IBOutlet weak var lblStudentmarks: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        lblUserID.text = String(describing: userID.value(forKey: "UserID")!);
        let studentList = Student.getAllStudent();
        var output = String()
        for (key,value) in studentList {
            
            output += " Student ID \(key)\n Student Name: \(value.studentName!) ";
        }
        lblUserID.text = output;
    }
    @IBOutlet weak var lblStudentGrade: UILabel!
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
